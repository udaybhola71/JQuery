// $(document).ready(function () {
//     $("h1").click(function () { 
//         // $(this).hide("slow");   
//         $(this).css("color", "red");      
//     });
// });
// document.addEventListener("keypress",function(event) {
//     // console.log(event.key);
//     if (event.key == "h" || event.key == "H") {
//         $("h1").hide("slow");
//     }
//     else{
//         $("h1").show("slow");

//     }
// })