//one btn for toggle fade property
$(document).ready(function () {

    //Two but for fadein and fade out
    // $("#FadeIn").css("opacity" , ".2")
    // $("#FadeIn").attr("disabled" , true) 
    // $("#FadeIn").click(function () { 
    //     $(".container").fadeIn("slow"); 
    //     $("#FadeOut").attr("disabled" , true)        
    //     $("#FadeIn").css("opacity" , ".2")       
    //     $("#FadeOut").css("opacity" , "1")       
    // });
    // $("#FadeOut").click(function () { 
    //     $(".container").fadeOut("slow");       
    //     $("#FadeIn").attr("disabled" , false)  
    //     $("#FadeOut").css("opacity" , ".2")    
    //     $("#FadeIn").css("opacity" , "1")      
    // });
});
