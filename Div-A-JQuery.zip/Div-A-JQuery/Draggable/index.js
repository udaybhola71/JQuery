let box1 = $("#box1");
let box2 = $("#box2");
let box3 = $("#box3");
let box4 = $("#box4");
let box5 = $("#box5");

$(document).ready(function () {
    $("#box1").draggable();

    box2.draggable({ delay: 500 });

    $("#box3 span").draggable({helper : "clone"})

    box4.draggable({distance: 50});

    $("#box5 span").draggable ({
        axis : "x"
     });

     $("#box6 span").draggable({containment :"#box6" })
});