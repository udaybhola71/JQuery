let Resizeble = $(".Resizeble");
let dropable = $(".dropable");
let sortable = $("#sortable");
let sortable2 = $("#sortable2");

$(document).ready(function () {
    Resizeble.resizable();

    $( "#draggable" ).draggable();
    $("#droppable").droppable({
        accept:"#draggable",
      drop: function() {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
            .html( "Dropped!" );
      }
    });

    sortable.sortable();
    sortable2.sortable();

   $( "#sortable, #sortable2" ).sortable({
      connectWith: ".connected"
    }).disableSelection();
});