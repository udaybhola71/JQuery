//one button for toggle hide and show
$(document).ready(function () {
    $("#btn").click(function () { 
        $(".container").toggle(2000);
        if ($("#btn").text() == "show") {
            $("#btn").text("hide")
        }  
        else $("#btn").text("show")
    });

//two btn for hide and show
$("#show").css("opacity",".2");
    $("#hide").click(function (e) { 
        $(".container").hide(2000);  
        $(this).css("opacity",".2"); 
        $("#show").css("opacity","1");
    });
    $("#show").click(function (e) { 
        $(".container").show(2000);  
        $(this).css("opacity",".2"); 
        $("#hide").css("opacity","1");
    });

//size increment decrement with jquery
    let width = $(".container").width();
    let height = $(".container").height();


    $("#increment").click(function (e) { 

        if (width<=500) {
            width += 50
            height += 50
            $(".container").width(width);       
            $(".container").height(height);       
        }
        else alert("Max width and height is 500px you cross your limit");

    });
    $("#decrement").click(function (e) { 

        if (width>=100) {
            width -= 50
            height -= 50
            $(".container").width(width);       
            $(".container").height(height);
        }
        else alert("min width and height is 50px you cross your limit")

    });
});